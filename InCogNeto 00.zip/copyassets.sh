#!/bin/bash
cp -r gdx-android/assets/ gdx-desktop
