cd `dirname $0`
java -cp "../gdx-desktop/bin/:\
../gdx-desktop/libs/gdx-backend-lwjgl.jar:\
../gdx-desktop/libs/gdx-backend-lwjgl-natives.jar:\
../gdx-desktop/libs/gdx-natives.jar:\
../gdx/bin/:\
../gdx/libs/gdx.jar" com.samphippen.explaygamejam2012.Main

